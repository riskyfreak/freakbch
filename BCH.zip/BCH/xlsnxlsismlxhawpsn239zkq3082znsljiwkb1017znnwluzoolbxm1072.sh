#!/usr/xbin/bash


clear
echo
echo "\033[32;1m  Jangan lupa untuk subscribe"
echo "\033[32;1mChanel youtube saya gratis ko :)"
echo "\033[32;1mSalin link di bawah 👇👇"
echo "\033[32;1mLINK \033[31;1m: \033[39;1mhttps://www.youtube.com/channel/UCphpdunNU_VmV081R-IDbSg"
echo
echo
echo "\033[33;1m    Pilih ini"
echo "\033[31;1m+-----------------+"
echo "\033[31;1m| \033[33;1m[\033[32;1m+\033[33;1m]\033[34;1m01\033[31;1m.\033[39;1mCOBA LAGI \033[31;1m|"
echo "\033[31;1m| \033[33;1m[\033[32;1m+\033[33;1m]\033[34;1m02\033[31;1m.\033[39;1mEXIT      \033[31;1m|"
echo "\033[31;1m+-----------------+"
echo "\033[31;1m"
read -p "PILIH NO : " rus
if [ $rus = 1 ] || [ $rus = 01 ];then
python2 bch.py
fi

if [ $rus = 2 ] || [ $rus = 02 ];then
exit
fi
